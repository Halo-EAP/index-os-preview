HALOS PROFILE DESIGNER  v0.4.0

TRY IT FIRST (no install)
  Double-click index.html (Chrome or Edge). Test works here too (allow pop-ups).
  Saving, Open folder and Update need the EXE.

BUILD THE WINDOWS EXE (one time)
  1. Install Node.js LTS from https://nodejs.org (keep the defaults).
  2. Double-click build-exe.bat
  3. The "dist" folder opens when it's done. The portable .exe runs anywhere.
  Manual: npm install, npm start (test), npm run dist (EXE), npm run dist:installer (Setup)

TEST WINDOW
  Press "Test": a phone window boots, shows the lock screen, then runs your profile.
  Gestures (when Navigation is "Gesture bar"):
    swipe up from the bottom bar ... go home / exit app / open the app drawer
    double-tap the bar ................ recent apps
    swipe in from the left edge ....... back
    swipe down from the top ........... notification shade
    swipe left/right on home .......... switch pages
    hold the home screen .............. edit mode (drag icons/widgets, + to add, wallpaper)
    swipe up on the lock screen ....... unlock
  Power and volume buttons are on the right of the phone. Power: tap = sleep/wake,
  hold = power menu (power off / restart). Map your own keys under the phone.
  Close with Esc, change the profile, press Test again.

ANIMATIONS
  Animations chip: style, speed and easing for app open/close, switcher, drawer,
  shade, lock, plus page-swipe speed and a custom easing curve.
  Custom animation files: see samples/*.json. Format:
    {"keyframes":[{"opacity":0,"transform":"scale(.8)"},{"opacity":1,"transform":"none"}]}
  Allowed properties: opacity, transform, filter (blur/brightness/saturate/contrast), offset.

WHERE PROFILES ARE SAVED
  Save .hui writes to  Documents\Halos Profiles\<profile-file-name>\<name>.hui
  "Open folder" opens that folder.

UPDATING THE APP (no rebuild needed after v0.3.0)
  Someone sends you a .hdu file. In the app press "Update", choose the file.
  The app checks it, installs it and restarts. "Revert to built-in version"
  (right panel, bottom) undoes an update.
  Limits: fonts up to 25 MB, images and animations up to 15 MB each.
  Limits: a .hdu updates the designer's interface (index.html). Changes to the
  EXE's own shell (main.js, preload.js, Electron) need a new EXE build.
  A .hdu is checked for damage (SHA-256) but NOT for who made it, so only
  install updates from someone you trust.

IF THE BUILD FAILS
  - "Cannot create symbolic link": enable Windows Developer Mode, or run the
    terminal as Administrator, then run build-exe.bat again.
  - Still stuck: in package.json inside "win": { ... } add
    "signAndEditExecutable": false
  - Antivirus / SmartScreen warning on an unsigned EXE: More info > Run anyway.

FILE FORMATS
  .hui  zip: manifest.json + profile.json + assets/ (images, fonts)
  .hdu  zip: manifest.json {magic HALOSUPD, app, version, files{index.html: sha256}} + index.html
