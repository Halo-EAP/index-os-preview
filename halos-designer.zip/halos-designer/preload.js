const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('halos', {
  save: (id, bytes) => ipcRenderer.invoke('save', { id, bytes }),
  openFolder: (id) => ipcRenderer.invoke('open-folder', id),
  applyUpdate: (u) => ipcRenderer.invoke('apply-update', u),
  resetUI: () => ipcRenderer.invoke('reset-ui'),
  reload: () => ipcRenderer.invoke('reload')
});
