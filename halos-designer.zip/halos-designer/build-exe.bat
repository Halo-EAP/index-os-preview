@echo off
cd /d "%~dp0"
echo Halos Profile Designer: building the Windows EXE
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install the LTS version from https://nodejs.org, then double-click this file again.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 (
  echo npm install failed. Check your internet connection and try again.
  pause
  exit /b 1
)
call npm run dist
if errorlevel 1 (
  echo The build failed. See README.txt, "If the build fails".
  pause
  exit /b 1
)
echo.
echo Done! Your EXE is in the "dist" folder.
start "" "%~dp0dist"
pause
