const { app, BrowserWindow, Menu, ipcMain, shell } = require('electron');
const fs = require('fs');
const path = require('path');

const uiDir = () => path.join(app.getPath('userData'), 'ui');          // updates live here
const root = () => path.join(app.getPath('documents'), 'Halos Profiles'); // saved profiles
const bundled = () => path.join(__dirname, 'index.html');
const okId = (id) => /^[a-z0-9-]{1,40}$/.test(id || '');
const cmp = (a, b) => {
  const x = a.split('.').map(Number), y = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0) ? 1 : -1;
  return 0;
};

// Use the updated UI only if it is newer than the version built into this EXE.
function entry() {
  try {
    const v = JSON.parse(fs.readFileSync(path.join(uiDir(), 'version.json'), 'utf8'));
    const f = path.join(uiDir(), 'index.html');
    if (cmp(v.version, app.getVersion()) > 0 && fs.existsSync(f)) return f;
  } catch (e) {}
  return bundled();
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 860, minWidth: 1000, minHeight: 700,
    title: 'Halos Profile Designer', backgroundColor: '#101014',
    webPreferences: { contextIsolation: true, nodeIntegration: false, preload: path.join(__dirname, 'preload.js') }
  });
  Menu.setApplicationMenu(null);
  // Only the Test window may be opened.
  win.webContents.setWindowOpenHandler(({ url }) => url.includes('#test')
    ? { action: 'allow', overrideBrowserWindowOptions: { width: 460, height: 900, title: 'Halos Test', backgroundColor: '#000000', autoHideMenuBar: true } }
    : { action: 'deny' });
  // If an updated UI fails to load, fall back to the built-in one.
  let fellBack = false;
  win.webContents.on('did-fail-load', () => { if (!fellBack) { fellBack = true; win.loadFile(bundled()); } });
  win.loadFile(entry());
}

ipcMain.handle('save', (e, { id, bytes }) => {
  if (!okId(id) || !bytes) throw new Error('bad profile');
  const dir = path.join(root(), id);
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, id + '.hui');
  fs.writeFileSync(file, Buffer.from(bytes));
  return { path: file, dir };
});
ipcMain.handle('open-folder', (e, id) => {
  const dir = okId(id) ? path.join(root(), id) : root();
  fs.mkdirSync(dir, { recursive: true });
  return shell.openPath(dir);
});
ipcMain.handle('apply-update', (e, { version, html }) => {
  if (!/^\d+\.\d+\.\d+$/.test(version) || !html || html.length > 3e6) throw new Error('bad update');
  fs.mkdirSync(uiDir(), { recursive: true });
  fs.writeFileSync(path.join(uiDir(), 'index.html'), Buffer.from(html));
  fs.writeFileSync(path.join(uiDir(), 'version.json'), JSON.stringify({ version }));
  return true;
});
ipcMain.handle('reset-ui', () => { fs.rmSync(uiDir(), { recursive: true, force: true }); return true; });
ipcMain.handle('reload', (e) => { BrowserWindow.fromWebContents(e.sender).loadFile(entry()); return true; });

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
